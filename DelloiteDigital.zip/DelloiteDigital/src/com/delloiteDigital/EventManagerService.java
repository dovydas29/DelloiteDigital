/**
 * Author : Dovydas Pliauga
 */

package com.delloiteDigital;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

public class EventManagerService {

	private int teams;
	private String csvFile;

	/**
	 * Constructor takes in a number of teams that are going to participate and
	 * the name of the file of activities (on the classpath).
	 * 
	 * @param teams
	 * @param csvFile
	 */
	public EventManagerService(int teams, String csvFile) {

		this.teams = teams;
		this.csvFile = csvFile;
	}

	/**
	 * No arg constructor for unit testing
	 */
	public EventManagerService() {
	}

	public int getTeams() {
		return teams;
	}

	public void setTeams(int teams) {
		this.teams = teams;
	}

	public String getCsvFile() {
		return csvFile;
	}

	public void setCsvFile(String csvFile) {
		this.csvFile = csvFile;
	}

	/**
	 * Main method which sorts, splits and organises team activities
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	public void schedule() throws NumberFormatException, IOException {

		String cvsSplitBy = ",";

		try (InputStream in = EventManagerRunner.class.getResourceAsStream(csvFile);
				BufferedReader br = new BufferedReader(new InputStreamReader(in))) {

			Map<String, Integer> activities = readActivities(cvsSplitBy, br);

			List<Entry<String, Integer>> sortedActivities = sortActivitiesByValue(activities);

			if (this.teams > 0) {

				List<Map<String, Integer>> teamActivities = new ArrayList<Map<String, Integer>>();

				for (int i = 0; i < this.teams; i++) {
					teamActivities.add(new HashMap<String, Integer>());
				}

				splitActivities(sortedActivities, teamActivities);

				printTeamSchedules(teamActivities);
			}
		}
	}

	/**
	 * Reads activities from a file and adds them to a HashMap
	 * 
	 * @param cvsSplitBy
	 * @param br
	 * @return
	 * @throws IOException
	 */
	private Map<String, Integer> readActivities(String cvsSplitBy, BufferedReader br) throws IOException {

		Map<String, Integer> activities = new HashMap<String, Integer>();

		String line;

		while ((line = br.readLine()) != null) {
			String[] activity = line.split(cvsSplitBy);

			activities.put(activity[0], Integer.valueOf(activity[1]));
		}

		return activities;
	}

	/**
	 * Splits activities into sub lists of each team
	 * 
	 * @param sortedActivities
	 * @param lists
	 */
	private void splitActivities(List<Entry<String, Integer>> sortedActivities, List<Map<String, Integer>> lists) {
		
		int team = 0;

		if (sortedActivities != null && sortedActivities.size() > 0) {
			for (Entry<String, Integer> activity : sortedActivities) {

				if (team == teams) {
					team = 0;
				}

				Map<String, Integer> teamList = lists.get(team);
				teamList.put(activity.getKey(), activity.getValue());
				team++;

			}
		}
	}

	/**
	 * Prints and organises activity schedules for each team
	 * 
	 * @param lists
	 */
	public void printTeamSchedules(List<Map<String, Integer>> lists) {

		SimpleDateFormat formatter = new SimpleDateFormat("h:mm a");
		int teamCounter = 1;

		for (Map<String, Integer> teamActivities : lists) {
			
			StringBuilder sb = new StringBuilder();
			
			//time the event starts
			Calendar c = new GregorianCalendar();
			c.set(Calendar.HOUR_OF_DAY, 9);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			Date currentTime = c.getTime();

			//time the event finishes
			Calendar c1 = new GregorianCalendar();
			c1.set(Calendar.HOUR_OF_DAY, 17);
			c1.set(Calendar.MINUTE, 0);
			c1.set(Calendar.SECOND, 0);
			Date finishTime = c1.getTime();

			//lunch time
			Calendar c2 = new GregorianCalendar();
			c2.set(Calendar.HOUR_OF_DAY, 12);
			c2.set(Calendar.MINUTE, 0);
			c2.set(Calendar.SECOND, 0);
			Date lunchTime = c2.getTime();

			//presentation time - cannot start earlier than this time
			Calendar c3 = new GregorianCalendar();
			c3.set(Calendar.HOUR_OF_DAY, 16);
			c3.set(Calendar.MINUTE, 0);
			c3.set(Calendar.SECOND, 0);
			Date presentationStartTime = c3.getTime();
			
			
			sb.append("\n");
			sb.append("Team " + getCharForNumber(teamCounter) + "\n");
			sb.append("\n");
			
			teamCounter++;

			Iterator it = teamActivities.entrySet().iterator();
			while (it.hasNext()) {

				long diff = lunchTime.getTime() - currentTime.getTime();
				long diffMinutes = TimeUnit.MILLISECONDS.toMinutes(diff);

				int activityLength = 0;

				if (finishTime.getTime() >= currentTime.getTime()) {

					currentTime = checkLunchTime(formatter, sb, c, currentTime, diffMinutes);
					
					Map.Entry pair = (Map.Entry) it.next();

					diff = finishTime.getTime() - currentTime.getTime();
					diffMinutes = TimeUnit.MILLISECONDS.toMinutes(diff);

					activityLength = Integer.valueOf(pair.getValue() + "");

					currentTime = addActivity(formatter, sb, c, currentTime, diffMinutes, activityLength, pair.getKey() + "");

				}

				diff = finishTime.getTime() - currentTime.getTime();
				diffMinutes = TimeUnit.MILLISECONDS.toMinutes(diff);

				boolean timeForPresentation = checkStaffPresentation(formatter, sb, c, presentationStartTime, diffMinutes, activityLength);
				
				if(timeForPresentation){
					break;
				}

			}
			
			System.out.println(sb);
		}
	}

	/**
	 * checks that staff presentation starts at the right time - not early and not too late
	 * @param formatter
	 * @param sb
	 * @param c
	 * @param presentationStartTime
	 * @param diffMinutes
	 * @param activityLength
	 * @return
	 */
	public boolean checkStaffPresentation(SimpleDateFormat formatter, StringBuilder sb, Calendar c,
			Date presentationStartTime, long diffMinutes, int activityLength) {
		
		boolean timeForPresentation = false;
		Date currentTime;
		
		if (activityLength >= diffMinutes) {

			c.add(Calendar.MINUTE, (int) diffMinutes);
			currentTime = c.getTime();

			if (currentTime.getTime() >= presentationStartTime.getTime()) {
				sb.append(formatter.format(currentTime) + " : " + "Staff Motivation Presentation\n");
				timeForPresentation = true;
			}
		}
		
		return timeForPresentation;
	}

	/**
	 * checks that activity can be added to the current schedule
	 * @param formatter
	 * @param sb
	 * @param c
	 * @param currentTime
	 * @param diffMinutes
	 * @param activityLength
	 * @param key
	 * @return
	 */
	public Date addActivity(SimpleDateFormat formatter, StringBuilder sb, Calendar c, Date currentTime,
			long diffMinutes, int activityLength, String key) {
		
		if (activityLength <= diffMinutes) {
			
			sb.append(formatter.format(currentTime) + " : " + key + "\n");
			c.add(Calendar.MINUTE, activityLength);
			currentTime = c.getTime();
			
		}
		return currentTime;
	}

	/**
	 * checks when lunch time can begin
	 * @param formatter
	 * @param sb
	 * @param c
	 * @param currentTime
	 * @param diffMinutes
	 * @return
	 */
	public Date checkLunchTime(SimpleDateFormat formatter, StringBuilder sb, Calendar c, Date currentTime,
			long diffMinutes) {
		
		if (diffMinutes <= 60 && diffMinutes >= 0) {
			
			sb.append(formatter.format(currentTime) + " : Lunch Break 60min\n");
			c.add(Calendar.MINUTE, 60);
			currentTime = c.getTime();
			
		}
		return currentTime;
	}

	/**
	 * Sorts activities by longest duration in a descending order
	 * 
	 * @param map
	 * @return
	 */
	static <K, V extends Comparable<? super V>> List<Entry<String, Integer>> sortActivitiesByValue(
			Map<String, Integer> map) {

		List<Entry<String, Integer>> sortedEntries = new ArrayList<Entry<String, Integer>>(map.entrySet());

		Collections.sort(sortedEntries, new Comparator<Entry<String, Integer>>() {
			@Override
			public int compare(Entry<String, Integer> e1, Entry<String, Integer> e2) {
				return e2.getValue().compareTo(e1.getValue());
			}
		});

		return sortedEntries;
	}

	/**
	 * Retrieves ASCII character equivalent of the int value supplied
	 * 
	 * @param i
	 * @return
	 */
	private String getCharForNumber(int i) {
		return i > 0 && i < 27 ? String.valueOf((char) (i + 64)) : null;
	}

}
