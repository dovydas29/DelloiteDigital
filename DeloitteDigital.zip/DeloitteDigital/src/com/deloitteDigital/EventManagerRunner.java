/**
 * Author : Dovydas Pliauga
 */

package com.deloitteDigital;

import java.io.IOException;
import java.text.ParseException;

public class EventManagerRunner {
	
	static String CSV_FILE = "/activities.csv";
	static int TEAM_SIZE = 2;

	public static void main(String[] args) throws ParseException, NumberFormatException, IOException {
		
	     EventManagerService eventManager = new EventManagerService(TEAM_SIZE, CSV_FILE);
	     eventManager.schedule();
	}
}
