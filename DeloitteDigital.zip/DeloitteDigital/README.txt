-------------------------------------------------------------------------------------------------------------
                                              Deloitte Digital Away Day Program Instructions

-------------------------------------------------------------------------------------------------------------

1. Unzip the project folder.
2. Using your preferred Development IDE import the project.
3. To run the program execute main method in the EventManager class.
4. The program can also be executed via command prompt by compiling the classes in the project.
5. To run the unit tests TestNG library is required.