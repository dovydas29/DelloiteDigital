/**
 * Author : Dovydas Pliauga
 */
package com.deloitteDigital.test;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.deloitteDigital.EventManagerService;

public class EventManagerServiceTest {
	
	private EventManagerService eventManagerService = new EventManagerService();
	private SimpleDateFormat formatter = new SimpleDateFormat("h:mm a");
	
	
	/**
	 * Test to ensure that lunch break cannot be taken after 12 o'clock as activities have to restart at 1.
	 */
	@Test
	public void checkLunchTimeTest(){
		
		Calendar c = new GregorianCalendar();
		c.set(Calendar.HOUR_OF_DAY, 12);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		Date currentTime = c.getTime();
		
		int minutesBeforeLunch = 0;
		
		//can take lunch as it's 12 noon or within an hour
		currentTime = eventManagerService.checkLunchTime(formatter, new StringBuilder(), c, currentTime, minutesBeforeLunch);
		Assert.assertEquals(formatter.format(currentTime), "1:00 PM");
		
		c.set(Calendar.HOUR_OF_DAY, 10);
		c.set(Calendar.MINUTE, 59);
		c.set(Calendar.SECOND, 0);
		currentTime = c.getTime();
		
		minutesBeforeLunch = 61;
		
		//can't take lunch not within an hour of it
		currentTime = eventManagerService.checkLunchTime(formatter, new StringBuilder(), c, currentTime, minutesBeforeLunch);
		Assert.assertEquals(formatter.format(currentTime), "10:59 AM");
		
	}
	
	/**
	 * Test to ensure activities are added to the schedule only if they're within allow time frame.
	 */
	@Test
	public void addActivityTest(){
		
		Calendar c = new GregorianCalendar();
		c.set(Calendar.HOUR_OF_DAY, 16);
		c.set(Calendar.MINUTE, 30);
		c.set(Calendar.SECOND, 0);
		Date currentTime = c.getTime();
		
		int timeLeft = 20;
		int activityLength = 15;
		
		//activity will be added as there's enough time to complete it before the finish time
		currentTime = eventManagerService.addActivity(formatter, new StringBuilder(), c, currentTime, timeLeft, activityLength, "");
		Assert.assertEquals(formatter.format(currentTime), "4:45 PM");
		
		timeLeft = 20;
		activityLength = 30;
		
		c = new GregorianCalendar();
		c.set(Calendar.HOUR_OF_DAY, 16);
		c.set(Calendar.MINUTE, 30);
		c.set(Calendar.SECOND, 0);
		currentTime = c.getTime();
		
		//activity will not be added as there's not enough time to complete it before the finish time
		currentTime = eventManagerService.addActivity(formatter, new StringBuilder(), c, currentTime, timeLeft, activityLength, "");
		Assert.assertEquals(formatter.format(currentTime), "4:30 PM");
		
	}
	
	/**
	 * Test to ensure that staff presentation starts at the right time not before 4 o'clock and not after 5 o'clock.
	 */
	@Test
	public void checkStaffPresentation(){
		
		Calendar c = new GregorianCalendar();
		c.set(Calendar.HOUR_OF_DAY, 16);
		c.set(Calendar.MINUTE, 00);
		c.set(Calendar.SECOND, 0);
		Date currentTime = c.getTime();
		
		int timeLeft = 20;
		int activityLength = 25;
		
		
		//time for presentation as activity length is longer than time until the end of day and current time is past presentation allow starting time
		boolean timeForPresentation = eventManagerService.checkStaffPresentation(formatter, new StringBuilder(), c, currentTime, timeLeft, activityLength);
		Assert.assertEquals(timeForPresentation, true);
		
		Calendar c2 = new GregorianCalendar();
		c2.set(Calendar.HOUR_OF_DAY, 17);
		c2.set(Calendar.MINUTE, 00);
		c2.set(Calendar.SECOND, 0);
		Date presentationTime = c2.getTime();
		
		//not time for presentation yet as current time is less
		timeForPresentation = eventManagerService.checkStaffPresentation(formatter, new StringBuilder(), c, presentationTime, timeLeft, activityLength);
		Assert.assertEquals(timeForPresentation, false);
		
	}

}
